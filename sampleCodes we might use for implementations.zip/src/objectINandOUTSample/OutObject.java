/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package objectINandOUTSample;

import java.io.*;

/**
 *
 * @author Eric
 */
public class OutObject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("awsome.awsomed"));

        Awsome awsome = new Awsome();
        awsome.increaseCounter();
        awsome.increaseCounter();
        out.writeObject(awsome);
        out.close();
        
    }
    
}
