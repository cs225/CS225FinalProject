/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package objectINandOUTSample;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 *
 * @author Eric
 */
public class ReadObject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        // TODO code application logic here
        ObjectInputStream in = new ObjectInputStream(new FileInputStream("awsome.awsomed"));
        Awsome awsome = (Awsome)in.readObject();
        System.out.println(awsome);
    }
}
