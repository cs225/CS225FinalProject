/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package objectINandOUTSample;

import java.io.Serializable;

/**
 *
 * @author Eric
 */
public class Awsome implements Serializable{
   
        private int counter = 0;

        public int getCounter() {
            return counter;
        }
        public  void increaseCounter(){
            counter++;
        }

        @Override
        public String toString() {
            return "Counter="+counter;
        }
        
        
    
}
