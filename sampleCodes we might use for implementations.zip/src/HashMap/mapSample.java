/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package HashMap;

import java.util.HashMap;

/**
 *
 * @author Eric
 */
public class mapSample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.values().toArray();//gets all the values
        map.put("Awsome", "awsome");//insert a new input
        System.out.println(map.get("Awsome"));//returns awsome
        System.out.println(map.get("nothing"));
        
    }
}
