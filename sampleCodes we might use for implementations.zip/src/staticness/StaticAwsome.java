/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package staticness;

/**
 *
 * @author Eric
 */
public class StaticAwsome {
    public static String string = "NOt Awsome yet";
    
}
