package DirectorySearchAccess;

import java.io.File;
import java.io.FileFilter;

/**
 *
 * @author Eric
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       File folder = new File("folder"+File.separator);// folder location
        
        
       File files[] = folder.listFiles(new 
               FileFilter() {
            @Override
            public boolean accept(File pathname) {
               if(pathname.toString().endsWith("txt"))// basically it records all files that ends with txt
                   return true;
               else
                   return false;
            }
        });
       
       for(int i = 0; i< files.length;i++)
           System.out.println(files[i].getName());
        
        
        folder.isDirectory();//returns true bc its a folder.
        folder.isFile();//returns false bc its not a folder.
    }
}
